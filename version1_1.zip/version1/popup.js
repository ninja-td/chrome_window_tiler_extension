document.getElementById("resize1").addEventListener("click", async () => {
  executeResize(1);
});

document.getElementById("resize2").addEventListener("click", async () => {
  executeResize(2);
});

document.getElementById("resize3").addEventListener("click", async () => {
  executeResize(3);
});
document.getElementById("resize4").addEventListener("click", async () => {
  executeResize(4);
});
document.addEventListener("keypress", (key) => {
  console.log(key);
  if (parseInt(key.key) > 0  && parseInt(key.key) < 5) {
    executeResize(parseInt(key.key));
  }
});

function executeResize(configNum) {
  chrome.windows.getCurrent(function(wind) {
    chrome.storage.local.get("resizeOption" + String(configNum), (result) => {
      console.log(result);
      resizeWindow(result[Object.getOwnPropertyNames(result)[0]], wind.id);
    });
  });
}

function resizeWindow(resizeOptions, windowId) {
  console.log(resizeOptions);
  if (resizeOptions) {
    var options = resizeOptions.split(",");
    var leftOp = Math.round(window.screen.availWidth * options[0] / 100);
    var topOp = Math.round(window.screen.availHeight * options[1] / 100);
    var widthOp = Math.round(window.screen.availWidth * options[2] / 100);
    var heightOp = Math.round(window.screen.availHeight * options[3] / 100);
    var updateInfo = {
        left: leftOp, //change those to whatever you like
        top: topOp,
        width: widthOp,
        height: heightOp,
    	state: "normal"
    };
    chrome.windows.update(windowId, updateInfo);

  }

}
